# === 🌐 Standard Library Imports ===
import os
import logging
import yaml

# === 🧠 External Package Imports ===
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from textblob import TextBlob

# === 📍 Define Base Directory for Project ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# === 📁 Define File Paths ===
CORPUS_FILE = os.path.join(BASE_DIR, 'Corpus', 'JFcorpus.yml')
LOG_FILE = os.path.join(BASE_DIR, 'AiLogs', 'chatlog.txt')
DATABASE_PATH = os.path.join(BASE_DIR, 'AiDataBase', 'database.db')
DATABASE_URI = f'sqlite:///{DATABASE_PATH}'

# === 📂 Create Required Folders ===
os.makedirs(os.path.dirname(CORPUS_FILE), exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)

# === 📝 Create Starting Corpus File if Missing ===
if not os.path.exists(CORPUS_FILE):
    with open(CORPUS_FILE, 'w', encoding='utf-8') as f:
        f.write("categories:\n- Custom Chat Logs\nconversations:\n")

# === 🧾 Configure Logging ===
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format='%(asctime)s - %(message)s'
)

# === 🤖 Create ChatBot Instance ===
JFbot = ChatBot(
    'JF_Aibot',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    database_uri=DATABASE_URI
)

# === 🧠 Setup Trainer ===
trainer = ListTrainer(JFbot)

# === 🧪 Sentiment Analyzer ===
def detect_sentiment(text):
    return round(TextBlob(text).sentiment.polarity, 2)

# === 📘 Update Corpus File from Logs ===
def update_corpus_from_logs():
    try:
        if os.path.exists(CORPUS_FILE):
            with open(CORPUS_FILE, 'r', encoding='utf-8') as f:
                corpus_data = yaml.safe_load(f) or {}
        else:
            corpus_data = {}
    except yaml.YAMLError:
        print("⚠️ Corpus YAML is malformed. Starting fresh.")
        corpus_data = {}

    corpus_data.setdefault("categories", ["Custom Chat Logs"])
    corpus_data.setdefault("conversations", [])

    with open(LOG_FILE, 'r', encoding='utf-8') as log:
        lines = log.readlines()
        for line in lines:
            if "User:" in line and "Bot:" in line:
                try:
                    user_msg = line.split("User: ")[1].split(" |")[0].strip()
                    bot_resp = line.split("Bot: ")[1].split(" |")[0].strip()
                    if [user_msg, bot_resp] not in corpus_data["conversations"]:
                        corpus_data["conversations"].append([user_msg, bot_resp])
                except IndexError:
                    continue

    with open(CORPUS_FILE, 'w', encoding='utf-8') as f:
        yaml.dump(corpus_data, f, allow_unicode=True)

    print("✅ Corpus updated successfully!")

# === 🔁 Retrain Bot from Corpus ===
def retrain_bot():
    try:
        with open(CORPUS_FILE, 'r', encoding='utf-8') as f:
            corpus_data = yaml.safe_load(f)

        conversations = corpus_data.get("conversations", [])

        valid_convos = [
            convo for convo in conversations
            if isinstance(convo, list) and all(isinstance(line, str) for line in convo)
        ]

        if not valid_convos:
            print("⚠️ No valid conversations found for training.")
            return

        for convo in valid_convos:
            trainer.train(convo)

        print(f"🔄 Retrained using {len(valid_convos)} conversations.")
    except Exception as e:
        print(f"⚠️ Retraining failed: {e}")

# === 💬 Chat Loop ===
def chat_loop():
    print("🧠 JF_Aibot is ready to chat! Type 'exit' to quit.\n")
    session_data = []

    while True:
        user_input = input("🗣️ You: ")
        if user_input.lower() == 'exit':
            print("👋 JF_Aibot: Thanks for chatting, Jeremi!")
            break

        response = str(JFbot.get_response(user_input))
        sentiment = detect_sentiment(response)

        print(f"🤖 JF_Aibot: {response}")
        session_data.append((user_input, response))
        logging.info(f"User: {user_input} | Bot: {response} | Sentiment: {sentiment}")

    print("\n📊 Here's what JF_Aibot learned from this session:\n")
    for msg, reply in session_data:
        print(f"🗣️ You: {msg}\n🤖 Bot: {reply}\n")

    feedback = input("📝 Was this session helpful? (yes/no): ").strip().lower()
    logging.info(f"Session Feedback: {feedback}")

    update_corpus_from_logs()
    retrain_bot()

# === 🚀 Launch Program ===
if __name__ == '__main__':
    chat_loop()