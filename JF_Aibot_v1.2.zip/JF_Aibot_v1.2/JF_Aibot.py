# === 🧠 JF A.I Bot: Chat, Learn, Reflect, Search ===

# === 🌐 Imports ===
import os, logging, yaml, requests
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from textblob import TextBlob
from transformers import BertTokenizer, BertForSequenceClassification
import torch
# === 📦 Auto-install missing packages ===
try:
    from bs4 import BeautifulSoup # type: ignore
except ImportError:
    import subprocess, sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4"])
    from bs4 import BeautifulSoup # type: ignore
# === 🔧 BERT Setup ===
tokenizer = BertTokenizer.from_pretrained("nlptown/bert-base-multilingual-uncased-sentiment")
model = BertForSequenceClassification.from_pretrained("nlptown/bert-base-multilingual-uncased-sentiment")

def classify_text(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True)
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
        predicted_class = torch.argmax(logits, dim=1).item()
        confidence = torch.softmax(logits, dim=1)[0][predicted_class].item()
    return predicted_class, round(confidence, 2)

# === 📍 Paths & Setup ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PATHS = {
    "corpus": os.path.join(BASE_DIR, 'Corpus', 'JFcorpus.yml'),
    "log": os.path.join(BASE_DIR, 'AiLogs', 'chatlog.txt'),
    "db": os.path.join(BASE_DIR, 'AiDataBase', 'database.db'),
    "insights": os.path.join(BASE_DIR, 'AiInsights', 'SessionInsights.txt'),
    "summaries": os.path.join(BASE_DIR, 'AiInsights', 'ChunkSummaries.txt')
}
DATABASE_URI = f'sqlite:///{PATHS["db"]}'

for path in PATHS.values():
    os.makedirs(os.path.dirname(path), exist_ok=True)

if not os.path.exists(PATHS["corpus"]):
    with open(PATHS["corpus"], 'w', encoding='utf-8') as f:
        f.write("categories:\n- Custom Chat Logs\nconversations:\n")

logging.basicConfig(filename=PATHS["log"], level=logging.INFO, format='%(asctime)s - %(message)s')

# === 🤖 Bot Initialization ===
JFbot = ChatBot('JF_Aibot', storage_adapter='chatterbot.storage.SQLStorageAdapter', database_uri=DATABASE_URI)
trainer = ListTrainer(JFbot)

def detect_sentiment(text):
    return round(TextBlob(text).sentiment.polarity, 2)

# === 🌐 GitHub Ingestion ===
GITHUB_REPOS = [
    'https://raw.githubusercontent.com/pallets/flask/main/README.md',
    'https://raw.githubusercontent.com/psf/requests/main/README.md'
]

def fetch_github_content():
    contents = []
    for url in GITHUB_REPOS:
        try:
            response = requests.get(url)
            if response.ok:
                contents.append(response.text)
        except Exception as e:
            print(f"⚠️ Error fetching {url}: {e}")
    return contents

def chunk_text(text, max_lines=10):
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    return [lines[i:i+max_lines] for i in range(0, len(lines), max_lines)]

def summarize_chunk(chunk):
    return f"Summary: {' '.join(chunk)[:200]}..."

def train_from_github(contents):
    for text in contents:
        for chunk in chunk_text(text):
            trainer.train([chunk[0], summarize_chunk(chunk)])
    print(f"✅ Trained on {len(contents)} GitHub sources.")

def save_summaries(contents):
    with open(PATHS["summaries"], 'a', encoding='utf-8') as f:
        for text in contents:
            for chunk in chunk_text(text):
                f.write(summarize_chunk(chunk) + "\n")
    print("📘 Summaries saved.")

# === 📘 Corpus Management ===
def load_corpus():
    try:
        with open(PATHS["corpus"], 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {"categories": ["Custom Chat Logs"], "conversations": []}
    except yaml.YAMLError:
        print("⚠️ Malformed corpus YAML. Starting fresh.")
        return {"categories": ["Custom Chat Logs"], "conversations": []}

def update_corpus_from_logs():
    corpus = load_corpus()
    with open(PATHS["log"], 'r', encoding='windows-1252') as log:
        for line in log:
            if "User:" in line and "Bot:" in line:
                try:
                    user = line.split("User: ")[1].split(" |")[0].strip()
                    bot = line.split("Bot: ")[1].split(" |")[0].strip()
                    if [user, bot] not in corpus["conversations"]:
                        corpus["conversations"].append([user, bot])
                except IndexError:
                    continue
    with open(PATHS["corpus"], 'w', encoding='utf-8') as f:
        yaml.dump(corpus, f, allow_unicode=True)
    print("✅ Corpus updated.")

def retrain_bot():
    corpus = load_corpus()
    convos = [c for c in corpus.get("conversations", []) if isinstance(c, list) and all(isinstance(x, str) for x in c)]
    if not convos:
        print("⚠️ No valid conversations.")
        return
    for convo in convos[:500]:
        trainer.train(convo)
    print(f"🔄 Retrained on {min(500, len(convos))} conversations.")

# === 🔍 Web Search Integration ===
def search_web(query):
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        response = requests.get(f"https://www.bing.com/search?q={query}", headers=headers)
        soup = BeautifulSoup(response.text, "html.parser")
        results = soup.find_all("li", class_="b_algo")
        if results:
            top = results[0]
            title = top.find("h2").text.strip()
            snippet = top.find("p").text.strip() if top.find("p") else "No snippet available."
            return f"🌐 {title}: {snippet}"
        else:
            return "🌐 No relevant web results found."
    except Exception as e:
        return f"⚠️ Web search error: {e}"

# === 🧠 Session Reflection ===
def reflect_on_session(data):
    insights = []
    for entry in data:
        sentiment = entry.get("textblob", 0.0)
        bert_data = entry.get("bert", {})
        bert_label = bert_data.get("label", "Unknown")
        bert_score = bert_data.get("score", 0.0)

        sentiment_label = "Neutral"
        sentiment_emoji = "🧩"
        if sentiment > 0.5:
            sentiment_label = "Positive"
            sentiment_emoji = "👍"
        elif sentiment < -0.5:
            sentiment_label = "Negative"
            sentiment_emoji = "👎"

        intent_emoji = {
            "Very Negative": "💢",
            "Negative": "👎",
            "Neutral": "🧩",
            "Positive": "👍",
            "Very Positive": "✅"
        }.get(bert_label, "❓")

        insights.append(
            f"{sentiment_emoji} Sentiment: {sentiment_label} ({sentiment}) | "
            f"{intent_emoji} BERT Intent: {bert_label} (Confidence: {bert_score})"
        )

    if insights:
        with open(PATHS["insights"], 'a', encoding='utf-8') as f:
            f.write("\n=== New Session ===\n" + "\n".join(insights) + "\n")
        print("🧠 Session insights saved.")
    else:
        print("ℹ️ No strong insights.")

# === 💬 Chat Loop ===
def chat_loop():
    print("🧠 JF_Aibot is ready! Type 'exit' to quit.\n")
    session = []

    intent_labels = {
        0: "Very Negative",
        1: "Negative",
        2: "Neutral",
        3: "Positive",
        4: "Very Positive"
    }

    while True:
        user_input = input("🗣️ You: ")
        if user_input.lower() == 'exit':
            print("👋 JF_Aibot: Thanks for chatting, Jeremi!")
            break

        response = str(JFbot.get_response(user_input))
        sentiment = detect_sentiment(response)
        intent_class, confidence = classify_text(user_input)
        intent_label = intent_labels.get(intent_class, "Unknown")
        web_result = search_web(user_input)

        print(f"🤖 JF_Aibot: {response}")
        print(f"🧠 BERT Intent: {intent_label} (Confidence: {confidence})")
        print(f"🧪 TextBlob Sentiment: {sentiment}")
        print(f"🌐 Web Insight: {web_result}")
        session.append({
            "user": user_input,
            "bot": response,
            "textblob": sentiment,
            "bert": {
                "label": intent_label,
                "score": confidence
            },
            "web": web_result
        })

        logging.info(f"User: {user_input} | Bot: {response} | Sentiment: {sentiment} | BERT: {intent_label} ({confidence}) | Web: {web_result}")

    reflect_on_session(session)
    # === 🏁 Main Entry Point ===
if __name__ == "__main__":
    github_data = fetch_github_content()
    train_from_github(github_data)
    save_summaries(github_data)
    update_corpus_from_logs()
    retrain_bot()
    chat_loop()